#!/usr/bin/env bash
set -euo pipefail

python code_review_agent.py review \
  --repo . \
  --target examples/bad_code_sample.py \
  --model "${AI_REVIEW_MODEL:-gpt-5.1}"
