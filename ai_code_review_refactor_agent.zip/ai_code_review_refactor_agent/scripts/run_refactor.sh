#!/usr/bin/env bash
set -euo pipefail

python code_review_agent.py refactor \
  --repo . \
  --from-json code_review.json \
  --patch-out refactor.patch \
  --model "${AI_REVIEW_MODEL:-gpt-5.1}"
