# AI Code Review / Refactor Agent

这是一个可直接运行的 AI 代码审查与重构 Agent MVP，适合用于项目申请、作品集、内部 Demo 或继续扩展成 CI Bot。

## 功能

- 扫描本地代码仓库
- 本地静态规则检查
- 调用 LLM 输出结构化代码审查结果
- 根据审查结果生成重构 patch
- 可选自动应用修改
- 可选执行 lint/test
- 测试失败时自动回滚

## 文件说明

```text
ai_code_review_refactor_agent/
├── code_review_agent.py      # 主程序
├── requirements.txt          # Python 依赖
├── .env.example              # 环境变量示例
├── README.md                 # 使用说明
├── examples/
│   └── bad_code_sample.py    # 可测试的示例代码
└── scripts/
    ├── run_review.sh         # 审查脚本
    └── run_refactor.sh       # 重构脚本
```

## 安装

```bash
cd ai_code_review_refactor_agent
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

配置 API Key：

```bash
export OPENAI_API_KEY="your_api_key"
```

也可以复制 `.env.example` 自己维护环境变量：

```bash
cp .env.example .env
```

## 快速测试

先不用 LLM，只跑本地静态扫描：

```bash
python code_review_agent.py review --repo . --target examples/bad_code_sample.py --no-llm
```

会生成：

```text
code_review.json
code_review.md
```

## 使用 LLM 审查代码

```bash
python code_review_agent.py review \
  --repo . \
  --target examples/bad_code_sample.py \
  --model gpt-5.1
```

扫描整个仓库：

```bash
python code_review_agent.py review --repo . --model gpt-5.1
```

只审查相对 Git HEAD 有改动的文件：

```bash
python code_review_agent.py review --repo . --only-changed --model gpt-5.1
```

## 生成重构 patch，但不直接改代码

```bash
python code_review_agent.py refactor \
  --repo . \
  --from-json code_review.json \
  --patch-out refactor.patch \
  --model gpt-5.1
```

查看 patch：

```bash
cat refactor.patch
```

## 自动应用重构，并跑测试

```bash
python code_review_agent.py refactor \
  --repo . \
  --from-json code_review.json \
  --apply \
  --test-cmd "pytest -q" \
  --model gpt-5.1
```

如果测试失败，默认会自动回滚。

## 推荐工作流

1. 先跑 `review`
2. 检查 `code_review.md`
3. 只对 `medium/high/critical` 的可重构问题生成 patch
4. 人工 review patch
5. 再用 `--apply --test-cmd` 自动验证
6. 提交 PR

## 可写进申请表的项目描述

我搭建了一个代码质量治理 Agent，用来解决老项目中技术债难发现、人工 Review 成本高、单测覆盖不足的问题。系统由扫描 Agent、审查 Agent、重构 Agent 和验证 Agent 协作：扫描 Agent 负责筛选改动文件并执行本地静态规则；审查 Agent 基于代码上下文输出结构化风险清单；重构 Agent 根据风险等级生成最小化 patch；验证 Agent 自动运行 lint/test，失败时回滚。该流程将低风险代码治理从人工排查转为自动化闭环，高风险问题则保留人工 Review，兼顾效率与安全性。

## 安全边界

- 默认不自动改代码
- `--apply` 后才会写文件
- 修改前会保存内存备份
- lint/test 失败默认回滚
- Prompt 中明确要求模型不要执行代码注释或字符串中的指令，降低 prompt injection 风险

## 常见参数

```bash
--repo                仓库路径
--target              指定文件，可重复传入
--model               模型名称
--max-files           最多扫描文件数
--max-file-bytes      单文件最大字节数
--no-llm              只跑本地规则
--only-changed        只审查 Git 改动文件
--from-json           使用 code_review.json 作为重构输入
--min-severity        最低修复级别，默认 medium
--patch-out           patch 输出文件
--apply               应用修改
--lint-cmd            lint 命令
--test-cmd            测试命令
--rollback-on-fail    失败回滚，默认开启
```

## 注意

不同账号可用模型名称可能不同。如果 `gpt-5.1` 不可用，请把命令里的 `--model` 改成你账号可用的模型。
