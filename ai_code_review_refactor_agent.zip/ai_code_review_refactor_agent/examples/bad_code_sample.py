import subprocess

api_key = "sk-this-is-a-fake-secret-for-demo"

def run_user_command(cmd):
    try:
        print("running command", cmd)
        return subprocess.check_output(cmd, shell=True).decode("utf-8")
    except Exception:
        return None

def calculate(expression):
    return eval(expression)

# TODO: add proper validation
def very_long_function_name_for_demo(user_input):
    return "This is a deliberately very very very very very very very very very very very very very very very very very long line for testing the static analyzer: " + str(user_input)
